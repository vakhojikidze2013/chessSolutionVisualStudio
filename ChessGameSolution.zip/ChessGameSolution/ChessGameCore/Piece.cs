﻿using System;

namespace ChessGameCore
{

    public class Piece
    {

        private string _name;

        public Piece(string name, string color, int positionX, int positionY )
        {
            _name = name;
            Color = color;
            PositionX = positionX;
            PositionX = positionY;
        }

        public string Name { 

            get
            {
                return _name;
            }

            set
            {
                _name = $"{Color}-{value}";
            } 
        }
        public string Color { get; set; }
        public int PositionX { get; set; }
        public int PositionY { get; set; }

    }

}
