﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ChessGameCore
{
    public class Rook : Piece
    {
        public Rook(string name, string color, int positionX, int positionY, int moveCount) 
            : base(name, color, positionX, positionY)
        {
            MoveCount = moveCount;
        }

        public List<Tuple<int, int>> GetMoves()
        {
            return new List<Tuple<int, int>> { new Tuple<int, int>(1, 2), new Tuple<int, int>(3, 2) };
        }

        public int MoveCount { get; set; }

    }

}
