﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace ChessGameView.Controllers
{
    public class GameController : Controller
    {
        public IActionResult Index()
        {
            return View();
        }

        public IActionResult GameView()
        {
            return View();
        }

        public IActionResult ChessGamesInfo()
        {
            return View();
        }

        public IActionResult ChessGameProcess()
        {
            return View();
        }
    }
}
