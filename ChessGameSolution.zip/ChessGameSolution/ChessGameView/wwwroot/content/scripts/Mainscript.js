//Setting information from server json for Magnus Carlsen
infoFromServerJsonPageOne(ConnectLinkPlayerList, Json, "#magnusCarlsen", "MagnusCarlsen");

//Setting information from server json for Hikaru Nakamura
infoFromServerJsonPageOne(ConnectLinkPlayerList, Json, "#hikaruNakamura", "HikaruNakamura");

//Setting information from server json for Nino Batsiashvili
infoFromServerJsonPageOne(ConnectLinkPlayerList, Json, "#ninoBatsiashvili", "NinoBatsiashvili");

//Setting information from json for Eric Hansen
infoFromServerJsonPageOne(ConnectLinkPlayerList, Json, "#ericHansen", "EricHansen");
